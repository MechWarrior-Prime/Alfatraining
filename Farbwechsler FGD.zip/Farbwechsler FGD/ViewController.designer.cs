﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Farbwechsler_FGD
{
    [Register ("ViewController")]
    partial class ViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblBlue { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblGreen { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOutput { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblRed { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblTitle { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISlider slrBlue { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISlider slrGreen { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISlider slrRed { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtBlue { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtGreen { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtRed { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (lblBlue != null) {
                lblBlue.Dispose ();
                lblBlue = null;
            }

            if (lblGreen != null) {
                lblGreen.Dispose ();
                lblGreen = null;
            }

            if (lblOutput != null) {
                lblOutput.Dispose ();
                lblOutput = null;
            }

            if (lblRed != null) {
                lblRed.Dispose ();
                lblRed = null;
            }

            if (lblTitle != null) {
                lblTitle.Dispose ();
                lblTitle = null;
            }

            if (slrBlue != null) {
                slrBlue.Dispose ();
                slrBlue = null;
            }

            if (slrGreen != null) {
                slrGreen.Dispose ();
                slrGreen = null;
            }

            if (slrRed != null) {
                slrRed.Dispose ();
                slrRed = null;
            }

            if (txtBlue != null) {
                txtBlue.Dispose ();
                txtBlue = null;
            }

            if (txtGreen != null) {
                txtGreen.Dispose ();
                txtGreen = null;
            }

            if (txtRed != null) {
                txtRed.Dispose ();
                txtRed = null;
            }
        }
    }
}