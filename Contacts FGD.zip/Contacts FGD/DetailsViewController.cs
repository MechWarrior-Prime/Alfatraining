using Foundation;
using System;
using UIKit;

namespace Contacts_FGD
{
    public partial class DetailsViewController : UITableViewController
    {
        public DetailsViewController (IntPtr handle) : base (handle)
        {
        }
    }
}